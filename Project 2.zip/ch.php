<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<style>
    body{
  padding-top: 50px;
  background-image: url('O2');
  text-align: left;
  background-repeat: no-repeat;
  background-attachment:fixed;
  background-size:100% 100%;
  color:black;
  margin-bottom: 10%;
  padding:5px;
  position: relative;
  margin-left: 100px;
  margin-right: 70px;
  margin-top:50px;
  }
 .c{
      padding-top:5px;
  }
 .i{
     padding-left:20px;
 }
 .fa {
  padding: 5px;
  font-size: 20px;
  width: 5px;
  text-align: center;
  text-decoration: none;
  margin: 1px 2px;
}
.n{
  color:black;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}
h2{
  text-align:center;
}
</style>
<body>
<div class="A">
<h1 class="c">Welcome To our Libirary</h1>
<h2>
<form action="search" method="post">
<i class="i">Search book</i>:<input type ="submit" value="click here" name="s" class=b1>
</form>
</h2>

    <h2>To Content with us:<h2>
    <a href ="mailto:mohmmedziyach@gmail.com"><div class="n"><i>mohmmedziyach@gmail.com</div></i></a>        
    <h2>Phone number: +249 992100934</h2>

</div>
</body>
</html>