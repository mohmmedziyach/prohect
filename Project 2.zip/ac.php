<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<body>
<style>
  .z{
    text-align:center;
    padding-top:10px;
  }
</style>
<h2>
    <div class="A">
        <i>
    <h1>Add Categories</h1> 
    <form method ="post">
    <label for="id">ID:</label>
    <input type="text" name="id" onfocus="this.value=''" value="Enter Categories ID" >
    <label for="name">name:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter Categories name">

    <br><br>
    &emsp;&emsp; <input type="submit" value="ADD" name="add" class="b1">
    &emsp;&emsp; <input type="submit" value="Delete" name="del" class="b1">
    &emsp;&emsp; <input type="submit" value="Update" name="up" class="b1"> <input type="text" class="l" name="cid" onfocus="this.value=''" value="catogorie id want to update">
    
<?php 
  $id=$_POST['id'];
  $na=$_POST['name'];
  $cid=$_POST['cid'];
  if($na=="Enter Categories name"|| $id=="Enter Categories ID")
 {
  echo "<script>alert('Please enter your name')</script>";
 }
 else
 {
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
  if($_POST['add']== true){
  $sql="INSERT INTO cat(id,name) VALUES('$id','$na')";
  if ($conn->query($sql)===TRUE)
{?><div class="z"><?php
	echo "new categorie created succesfully ";?></div><?php
}

else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}
}
if($_POST['del']== true){
  $sql="DELETE FROM cat WHERE name='$na' && id='$id'";
  if($conn->query($sql)==true)	
  {
    echo " record deleted";
  }
  else
  {
      echo "error in deleting record".$conn->error;
  }
}
if($_POST['up']== true){
  $sql="UPDATE cat SET name='$na',id='$id' WHERE id='$cid'";
  if ($conn->query($sql)===TRUE)
  {
    echo "user updated succesfully ";
  } 
  else 
  {
    echo "Erorr:".$sql."<br>".$conn->erorr;
  }
}
}
?>
</h2>
</form>
</i>

</div>
</body>
</html>