<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>

<body>

<h2>
    <div class="A">
        <i>
    <h1>Orders</h1> 
    <form method ="post">
    <label for="name">Name:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter order name" >
    <label for="name">B:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter book name">
    <label for="p">Price:</label>
    <input type="text" name="asc" onfocus="this.value=''" value="Enter book price">
    <br><br>
    &emsp;&emsp; <input type="submit" value="ADD" name="submit" class="b1">
    &emsp;&emsp; <input type="submit" value="Delete" name="submit" class="b1">
    &emsp;&emsp; <input type="submit" value="Update" name="submit" class="b1">
                                                                                                                                                                                                                                                        
</h2>
</form>
</i>
   </div>
</body>
</html>