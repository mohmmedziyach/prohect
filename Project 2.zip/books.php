<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<body>

<h2>
    <div class="A">
        <i>
    <h1>Books Records</h1> 
    <form method ="post">
    <label for="name">Name:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter book name" >
    <label for="name">Categories:</label>
    <input type="text" name="c" onfocus="this.value=''" value="Enter Catogrie name">
    <label for="sc">Sub Catogries:</label>
    <input type="text" name="sc" onfocus="this.value=''" value="Enter Sub Catogrie name">
    <label for="p">Price:</label>
    <input type="text" name="p" onfocus="this.value=''" value="Enter book price">
    <br><br>
    &emsp;&emsp; <input type="submit" value="ADD" name="add" class="b1">
    &emsp;&emsp; <input type="submit" value="Delete" name="del" class="b1">
    &emsp;&emsp; <input type="submit" value="Update" name="up" class="b1">
    <input type="text" class="l" name="cid" onfocus="this.value=''" value="catogorie id want to update">
    
</h2>
</form>
</i>
   </div>
</body>
</html>
<?php 
  $na=$_POST['name'];
  $c=$_POST['c'];
  $sc=$_POST['sc'];
  $p=$_POST['p'];
  $cid=$_POST['cid'];
  if($na=="Enter book name"|| $c=="Enter Catogrie name" || $sc=="catogorie id want to update" || $p=="Enter book price")
 {
    echo "<script>alert('Please enter Full catogries data')</script>";
 }
 else
 {
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="SELECT * FROM cat WHERE name='$c'";
$result1 =mysqli_query($conn, $sql);
if($result1->num_rows > 0)
{
$sql="SELECT * FROM scat WHERE name='$sc'";
$result =mysqli_query($conn, $sql);
if($result->num_rows > 0)
{
  if($_POST['add']== true)
  {
$sql="INSERT INTO books(name,cat,subcat,prize) VALUES('$na','$c','$sc','$p')";
 if ($conn->query($sql)===TRUE)
{
	echo "new user created succesfully ";
}
else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}

}
if($_POST['del']== true){
  $sql="DELETE FROM books WHERE name='$na'";
  if($conn->query($sql)==true)	
  {
    echo " record deleted";
  }
  else
  {
      echo "error in deleting record".$conn->error;
  }
}
if($_POST['up']== true){
  $sql="UPDATE books SET name='$na',cat=' $c',subcat=' $sc',prize='$p' WHERE id='$cid'";
  if ($conn->query($sql)===TRUE)
  {
    echo "user updated succesfully ";
  } 
  else 
  {
    echo "Erorr:".$sql."<br>".$conn->erorr;
  }
}
}
else
{
echo "<script>alert('sub catogorie doesnt found')</script>";	
}
}
else
{
echo "<script>alert('catogorie doesnt found')</script>";	
}
}
?>