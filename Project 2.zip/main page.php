<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<style>
h1{
    text-align: center;
    
}
.a{
   text-align: center;
}
</style>
<body>
<i>
<div class="A">
<h1>Welcome to our Libirary</h1>
<h1>You will find any type of book you want </h1>
<h1>Now login</h1>

<form method="post">
    <div class="a"><input type="submit" name="log" value="login" class="b1">
</form>
<h1>or sign in</h1>
<form method="post">
    <input type="submit" name="sign" value="sign in" class="b1">
</form>
</div>
</div>
</i>
</body>
</html>
<?php 
if ($_POST["log"]== True)
{
    echo '<script
type="text/javascript">window.location.href="log.php";</script>';
}
if ($_POST["sign"]== True)
{
    echo '<script
type="text/javascript">window.location.href="reg.php";</script>';
}
?>