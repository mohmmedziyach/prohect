<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
<style>
.x{
  margin-left:600px;
  padding-left:60px;
}
th,td,table{
    border: lightcoral solid;
    border-collapse:collapse ;
    margin-left:200px;
    padding-left:60px;
}

th{
  background-color:black;  
  padding-right:50px;
}
h2{
  padding-left:10px;
}
</style>
</head>
<body>
<div class="A">
<h1>Cart</h1>    
<br>
<h2><form method="post">
  <label for="name">name:</label>
    <input type="text" name="na" onfocus="this.value=''" value="Enter your name">
<br><br>
    <table class="tb">
     <tr>
       
       <th>name</th>
       <th>prize</th>
     </tr>
     </table>
<?php  
     if ($_POST["buy"]== True)
     {
     $n=$_POST['na'];
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}


$sql="SELECT * FROM accounts where name='$n'";
$result2 =mysqli_query($conn, $sql);
if($result2->num_rows > 0)
{
$nn=$n;
}
else{
    echo "<script>alert('your name dosent found in accounts')</script>";
}
$sql="SELECT * FROM books  where name='$s'";
$result2 =mysqli_query($conn, $sql);
if($result2->num_rows > 0)
{
while($row = $result2->fetch_assoc()){
?>

<table class="tb">
     <tr>
       <td><label><?php echo $row['name']; ?></label></td>
       <td><label><?php echo $row['prize']; ?></label></td>
     </tr>
     </table>
    
<?php
$b=$row['name'];
$x=(int) $row['prize'];
$y=$y+$x;
}
?>
<table class="tb">
     <tr>
       <td><label>total</label></td>
       <td><label><?php echo $y; ?></label></td>
     </tr>
     </table>
<?php
}
}
$sql="INSERT INTO orders (name,book,prize) VALUES('$nn','$b','$y')";
if($_POST['na']=="Enter your name"){
  echo "<script>alert('enter your name')</script>";
}
else{
if ($conn->query($sql)===TRUE)
{
 echo"Your treatment was done succesfully";
}
else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}

}

?>
<br>
     <div class="x"><input type="submit" name="buy" class="b1" value='BUY'><div>
     </form></h2>
 
</body>
</html>