﻿<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
</head>
<link rel="stylesheet" href="book.css">
<style>
    th,td,table{
    border: lightcoral solid;
    border-collapse: separate;

}

th,td{
    padding-right:50px;
}

</style>
<body>
<h2>
    <div class="A">
        <i>
    <h1>Search book</h1> 
    <form method ="post" >
    <label for="name">name:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter book name">
    <label for="c">Catogries:</label>
    <input type="text"  name="c" onfocus="this.value=''" value="Enter Catogrie name" >
    <label for="sc">Sub Catogries:</label>
    <input type="text" name="sc" onfocus="this.value=''" value="Enter Sub Catogrie"><br><br>
    &emsp;&emsp;<input type="submit" name="submit" class="b1">

<?php 

  $na=$_POST['name'];
  $c=$_POST['c'];
  $sc=$_POST['sc'];
  if ($_POST["submit"]== True)
{
  if($na=="Enter book name"|| $c=="Enter Catogrie name" || $sc=="Enter Sub Catogrie")
 {
    echo "<script>alert('Please enter Full book data')</script>";
 }
 else
 {
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="SELECT * FROM cat WHERE name='$c'";
$result1 =mysqli_query($conn, $sql);
if($result1->num_rows > 0)
{
$sql="SELECT * FROM scat WHERE name='$sc'";
$result =mysqli_query($conn, $sql);
if($result->num_rows > 0)
{
$sql="SELECT * FROM books WHERE name='$na'";
$result2 =mysqli_query($conn, $sql);
if($result2->num_rows > 0)
{
while($row = $result2->fetch_assoc()){
?>
<table class="tb">
     <tr>
       <th>name</th>
       <th>cat</th>
       <th>subcat</th>
       <th>price</th>
     </tr>
     <tr>
       <td><label name='n'><?php echo $row['name']; ?></label></td>
       <td><label name='ca'><?php echo $row['cat']; ?></label></td>
       <td><label name='sbc'><?php echo $row['subcat']; ?></label></td>
       <td><label name='p'><?php echo $row['prize']; ?></label></td>
     </tr>
     </table>
       &emsp;&emsp;<input type ="submit" name="b" value="Add to cart "  class="b1">
        
<?php
}
}
else
{
    echo "<script>alert('book doesnt found')</script>";
}
}
else
{
    echo "<script>alert('sub catogorie doesnt found')</script>";	

}
}
else
{
    echo "<script>alert('catogorie doesnt found')</script>";	

}

}
}
if ($_POST["b"]== True)
{
    echo '<script
type="text/javascript">window.location.href="atc.php";</script>';
}
?>
</h2>
</form>
</i>
</div>
</body>
</html>