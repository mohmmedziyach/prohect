<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<style>
    .n{
        text-align:center;
        padding-bottom:30px ;   
    }
</style>
<body>
    
<div class="A">
<form action ="" method ="post">
    <H1> WELCOME ADMIN</H1>
    <br><br><br>
    <div class="n">
    <input class="b1" type="submit" value="CATEGORIES" name="AC">
    <input class="b1" type="submit" value="SUB CATEGORIES" name="AS">
    <input class="b1" type="submit" value="BOOKS" name="AB">
    <input class="b1" type="submit" value="CHECK USERS" name="CU">
    <input class="b1" type="submit" value="CHECK ORDERS" name="CO">
    <input class="b1" type="submit" value="LOG OUT" name="LO"></div>
    </form>

</div>

</body>
<?PHP
if ($_POST["AC"]== True)
{
    echo '<script
type="text/javascript">window.location.href="ac.php";</script>';
}
if ($_POST["AS"]== True)
{
    echo '<script
type="text/javascript">window.location.href="asc.php";</script>';
}
if ($_POST["AB"]== True)
{
    echo '<script
type="text/javascript">window.location.href="books.php";</script>';
}
if ($_POST["CU"]== True)
{
    echo '<script
type="text/javascript">window.location.href="ce.php";</script>';
}
if ($_POST["CO"]== True)
{
    echo '<script
type="text/javascript">window.location.href="orders.php";</script>';
}
if ($_POST["LO"]== True)
{
    echo '<script
type="text/javascript">window.location.href="log.php";</script>';
}

?>

</html>