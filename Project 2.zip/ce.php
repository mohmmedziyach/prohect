<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
<style>
body {
  font-family: 'Nunito', sans-serif;
  color: #384047;
}

table {
  max-width: 960px;
  margin: 10px auto;
}

thead th {
  font-weight: 400;
  background: #8a97a0;
  color: #FFF;
  margin-right:200px;
 }
tr {
  background: #f4f7f8;
  border-bottom: 1px solid #FFF;
  margin-bottom: 5px;
}
 tr:nth-child(even) {
  background: #e8eeef;
}

td {
  padding-bottom:10px;
  padding-top:10px;
  padding-right:100px;
  font-size: 1.1em;
  font-style: italic;
  color: #8a97a0;
}
th, td {
  text-align: left;
  padding-right: 100px;
  font-weight: 300;
  padding-top:10px;
  padding-bottom:10px;
  font-size: 1.1em;
}

</style>
</head>
<body>

    <br><br>
    <table>
<h1>Check users</h1> 
    <thead>
      <tr> 
       <th scope="col"> name</th>
       <th scope="col">age</th>
       <th scope="col">email</th>
       <th scope="col">password</th>
       <th scope="col">favorite</th>
       <th scope="col">gender</th>
      
      </tr>
    </thead>
</div>
     </table>
<?php
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="SELECT * FROM accounts";
$result2 =mysqli_query($conn, $sql);
if($result2->num_rows > 0)
{
while($row = $result2->fetch_assoc()){
?>

<table>

     <tr>
       <td><?php echo $row['name']; ?></td>
       <td><?php echo $row['age']; ?></td>
       <td><?php echo $row['email']; ?></td>
       <td><?php echo $row['password']; ?></td>
       <td><?php echo $row['favorite']; ?></td>
       <td><?php echo $row['gender']; ?></td>
     </tr>

     </table>
    
<?php
}
}
?>
 <br><br>
</body>
</html>