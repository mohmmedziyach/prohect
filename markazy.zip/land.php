<?php
error_reporting(0)
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="land.css">
    </head>
    <body>
        <section class="s">
            <article class="m">
                <i><p><img src="10.png">Markazy</p></i>
                <div class="inputBox">
                    <form method="post">
                        <input type="submit" name="log" value="log In">
                    </form>
                </div>        
            </article>
            <article class="n">
                <p>Lorem ipsum dolor sit amet </p>
            </article>
            <article class="l">
                <p>Make Your Jop easy </p>  
            </article>
        </section>
    </body>
</html>
<?php
if ($_POST["log"]== True){
    echo '<script
    type="text/javascript">window.location.href="ch.php";</script>';
    }
?>