<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="reg.css">
    </head>
    <body>
        <div class="reg">
            <div class="contactForm">
                <form method="post">
                    <h2>Business</h2>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">    
                        <span>Email</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">
                        <span>Name</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">
                        <span>Company Name</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">    
                        <span>Password</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">    
                        <span>Role</span>
                    </div>
                    <div class="inputBox">
                        <input type="submit" name="submit" value="Sign In">         
        </div>
    </body>
</html>