<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="log.css">
    </head>
    <body>
        <section class="log">
            <article class="contactForm">
                <form method="post">
                    <h2>What are Your Jop?</h2>
                    <input type="radio" value="m" name="g">Bussiness &emsp;
                    <input type="radio" value="f" name="g">Farmer &emsp;
                    <div class="inputBox">
                    <input type="submit" name="sign" value="Enter"> 
                    </div>
                </form>
                <form method="post">
                    <h2>Have Account?</h2>
                    <div class="inputBox">
                    <input type="submit" name="sign" value="Log in"> 
                    </div>
                </form>
            </article>
        </section>
    </body>
</html>
