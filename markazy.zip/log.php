<?php
error_reporting(0)
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="Log.css">
    </head>
    <body>
        <section class="log">
            <article class="contactForm">
                <form method="post">
                    <h2>Log In</h2>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">    
                        <span>Email</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="aa" required="required">
                        <span>Name</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="aaa" required="required">    
                        <span>Password</span>
                    </div>
                    <div class="inputBox">
                    <input type="submit" name="log" value="Log In"> 
                    </div>
                </form>
            </article>
        </section>
    </body>
</html>
<?php
if ($_POST["log"]== True){
    $conn=new mysqli("localhost","root","","markazy");
    $user=$_POST['em'];
    $pass=$_POST['pass'];
    if($conn->connect_error)
        
    {
        die("Connection failed:".$conn->connect_error);
    }
    $sql="SELECT * FROM rego WHERE email='$user' AND password='$pass'";
    $result =mysqli_query($conn, $sql);
    if($user=='admin' AND $pass=='123456789')
    {
        echo '<script
        type="text/javascript">window.location.href="admin.php";</script>';
    }
    if($result->num_rows > 0)
    {
    $_SESSION['em'] = $row['email'] && $_SESSION['pass'] = $row['password'];
    echo '<script
    type="text/javascript">window.location.href="ch.php";</script>';
    }
    else
    {
    echo "<script>alert('wrong email or password')</script>";	
    }
    }
    ?>