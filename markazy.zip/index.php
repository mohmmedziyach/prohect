<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="index.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    </head>
    <body>
        <section class="nav">
            <article>
                <header>
                    <nav>
                        <p class="markazy"><img src="10.png">Markazy </p>
                        <a href="#" class="a">Home</a>
                        <a href="#"class="b">Profile</a>
                        <a href="#"class="c">About</a>
                        <a href="#"class="d">Comments</a>
                        <a href="#"class="f">Help</a>
                        <a href="#"class="g">Sign Out</a>
                    </nav>
                </header>
            </article>
        </section>
        <main>
            <section class="jambbotron">
                <article>
                    <p class="m">Welcome to Markazy Shop</p>
                    <p class="l">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
                </article>
            </section>
            <section class="pro">
                        <article class="carde">
                            <img src="15.jpg" alt="nj" style="width:100%">
                            <h1>Tailored Jeans</h1>
                            <p class="price">$19.99</p>
                            <p>Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.</p>
                            <p><button>Add to Cart</button></p>
                        </article>
                        <article class="card">
                            <img src="15.jpg" alt="nj" style="width:100%">
                            <h1>Tailored Jeans</h1>
                            <p class="price">$19.99</p>
                            <p>Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.</p>
                            <p><button>Add to Cart</button></p>
                        </article>
                        <article class="carda">
                            <img src="15.jpg" alt="nj" style="width:100%">
                            <h1>Tailored Jeans</h1>
                            <p class="price">$19.99</p>
                            <p>Some text about the jeans. Super slim and comfy lorem ipsum lorem jeansum. Lorem jeamsun denim lorem jeansum.</p>
                            <p><button>Add to Cart</button></p>
                        </article>
            </section>
        </main>
        <footer class="footer">
            <section class="container">
                <article class="row">
                    <div class="footer-col">
                        <h4>Company</h4>
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Our Services</a></li>
                            <li><a href="#">lorm</a></li>
                            <li><a href="#">lorm</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Get Help</h4>
                        <ul>
                            <li><a href="#">lorm</a></li>
                            <li><a href="#">shipping</a></li>
                            <li><a href="#">returns</a></li>
                            <li><a href="#">order status</a></li>
                            <li><a href="#">payment options</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Onlie shop</h4>
                        <ul>
                            <li><a href="#">frutis</a></li>
                            <li><a href="#">vegetables</a></li>
                            <li><a href="#">cotton</a></li>
                            <li><a href="#">suger</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Follow Us</h4>
                        <article class="Social-links">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </article>
                    </div>    
                </article>
            </section>
        </footer>
    </body>
</html>