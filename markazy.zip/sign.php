<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="sign.css">
    </head>
    <body>
        <section class="sign">
            <article class="contactForm">
                <form method="post">
                    <h2>sign In</h2>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">    
                        <span>Email</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="a" required="required">
                        <span>Name</span>
                    </div>
                    <div class="inputBox">
                    <input type="submit" name="submit" value="Sign In"> 
                    </div>
                    <p>Not have account?</p><div class="inputBox">
                    <input type="submit" name="submit" value="Sign In"> 
                    </div>
                </form>
            </article>
        </section>
    </body>
</html>