<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" type="text/css" href="About.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>       
</head>
<body>
    <section class="contact">
        <div class="content">
            <h2>Contact Us</h2>
            <p>Join a new World and have a good journey.</p>
        </div>
        <div class="container">
            <div class="contactInfo">
                <div class="box">
                    <div class="icon"></div>
                        <div class="text">
                            <h3>Address</h3>
                            <p></p>
                        </div>
                </div>
                <div class="box">
                    <div class="icon"></div>
                        <div class="text">
                            <h3>Phone</h3>
                            <p>+249992100934</p>
                        </div>
                    </div>
                    <div class="box">
                        <div class="icon"></div>
                            <div class="text">
                                <h3>Email</h3>
                                <p>mohmmedziyach@gmail.com</p>
                            </div>
                        </div>
            </div>
            <div class="contactForm">
                <form method="post">
                    <h2>Send Message</h2>
                    <div class="inputBox">
                        <input type="text" name="" required="required">
                        <span>Full Name</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="" required="required">
                        <span>Email</span>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="" required="required">
                        <span>Enter Your Message...</span>
                    </div>
                    <div class="inputBox">
                        <input type="submit" name="submit" value="Send">
                    </div>
                </form>
            </div>
        </div>
    </section>
</body>
</html>
