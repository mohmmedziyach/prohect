<!DOCTYPE html>
<html><head><title>football gaming</title></head>

<style>
body{
        text-align: center;
        background-image: url('Dy.jpg');
        background-repeat: no-repeat;
        background-attachment:fixed;
        background-size:100% 100%;
        color:black;
        margin-bottom: 10%;
        padding:5px;
        position: relative;
      
    }
           
    h1{
        text-align: center;
        font-family:rgb(13, 255, 0)/Black,sans-serif;
        font-size: 70px;
        text-shadow: 2px 2px 2px rgb(9, 255, 0);
    }
    .abc{
        border: 2px solid rgb(8, 222, 8, 0.728);
        border-spacing: 10px;
        background-color:#0000007c;
        color: aliceblue;
        width: 900px;
        margin-left: 125px;
        border-radius: 80px;
        box-shadow: rgba(8, 222, 8, 0.728) 0px 30px 60px -12px inset,rgba(79, 25, 218, 0.831) 0px 18px 36px -18px inset;
    }
    input[type="radio"]{
        color: white;
    }
    .s
    {
        border: 2px solid darkblue;
        border-radius: 80px;
        box-shadow: rgba(8, 222, 8, 0.728) 0px 30px 60px -12px inset,rgba(79, 25, 218, 0.831) 0px 18px 36px -18px inset;
        color: white;
        background-color:green;
        width:200px;
        margin-left: 474px;
        font-family:rgb(21, 255, 0)/Black,sans-serif;
    }
    .b1 {
        background: linear-gradient(to bottom right, #01fd5e, #7de06c);
        border: 0;
        border-radius: 12px;
        color: #FFFFFF;
        cursor: pointer;
        display: inline-block;
        font-family: -apple-system,system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
        font-size: 16px;
        font-weight: 500;
        line-height: 2.5;
        outline: transparent;
        padding: 0 1rem;
        text-align: center;
        text-decoration: none;
        transition: box-shadow .2s ease-in-out;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        white-space: nowrap;
        display:inline-block;
      }
      
      .b1:not([disabled]):focus {
        box-shadow: 0 0 .25rem rgba(0, 0, 0, 0.5), -.125rem -.125rem 1rem rgba(0, 255, 4, 0.5), .125rem .125rem 1rem rgba(0, 255, 4, 0.5);
      }
      
      .b1:not([disabled]):hover {
        box-shadow: 0 0 .25rem rgba(0, 0, 0, 0.5), -.125rem -.125rem 1rem rgba(0, 255, 4, 0.5), .125rem .125rem 1rem rgba(0, 255, 4, 0.5);
      }
      input[type=text]{
      width:100%;
      border:0;
      padding-left:5px;
      padding-top:2px;
      background-color:rgba(8, 106, 72, 0.666);
      box-sizing:border-box;
      outline: transparent;
      text-align:center;
      color:white;
      cursor: pointer;
      text:italic;
      font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
      }
      </style>
<body>
<div class="abc">
<h1 ><i>Paolo Dybala</i></h1>
<i>
<h2>    
<form  action="" method="post">
<label for="Name">Name</label>
<div class="i">
<input type="text" onfocus="this.value=''" value="Enter your name">
</div> 
<h1>let's GO!</h1>
<h3>1.In which team he is playing now?</h3>

    
    <input type="radio"  id="1" value="a1" name="a">Juventus &emsp;
    <input type="radio"  id="2" value="a2" name="a">Barclona &emsp;
    <input type="radio"  id="3" value="a3" name="a">Paris San Geirman &emsp;
 


<h3>2.How old is he?</h3>
    <input type="radio"  id="1" value="a1" name="b">28 &emsp;
    <input type="radio"  id="2" value="a2" name="b">25 &emsp;
    <input type="radio"  id="3" value="a3" name="b">32


<h3>3.trophy he didn't won ?</h3>
    <input type="radio"  id="1" value="a1" name="c">Uefa Champions Leage &emsp;
    <input type="radio"  id="2" value="a2" name="c">Italia Cup &emsp;
    <input type="radio"  id="3" value="a3" name="c">SriA


<h3>4.How many teams he played with ?</h3>

    <input type="radio" id="1" value="a1"  name="d">1 Team &emsp;
    <input type="radio" id="2" value="a2" name="d">2 Teams &emsp;
    <input type="radio" id="3" value="a3" name="d">3 Teams


<h3>5.How many ballondors he won ?</h3>

    <input type="radio"  id="1" value="a1" name="e">1 &emsp;
    <input type="radio"  id="2" value="a2" name="e">7 &emsp;
    <input type="radio"  id="3" value="a3" name="e">0
    
    &emsp;&emsp;<input type ="submit" name="submit"button class="b1" role="button" name="button">
    
</form>
</h2>
</div>

<?php

$i==0;
if ($_POST['submit']==true){
    
if ($_POST["a"]=="a1"){
    $i==$_POST['a'];
    $i=$i+20;
}
else {
    $i;
}
    

if ($_POST['b']=="a1"){
    $i==$_POST['b'];
    $i=$i+20;
}
else {
    $i;
}
if ($_POST["c"]=="a1"){
    $i==$_POST['c'];
    $i=$i+20;
}
else {
    $i;
}
if ($_POST["d"]=="a2"){
    $i==$_POST['d'];
    $i=$i+20;
}
else {
    $i;
}
if ($_POST["e"]=="a3"){
    $i==$_POST['e'];
    $i=$i+20;
}
else {
    $i;
}
 
?>
<div class="s">
<?php 
echo "Welcome",($i),'%';
}
?>
</div>
</h2>
</i>
</body>
</html>
