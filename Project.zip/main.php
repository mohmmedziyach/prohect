<?php 
ob_start();
?>
<!DOCTYPE html>
<html><head><title>Football Gaming</title>
</head>
<style>
    body{
        text-align: center;
        background-image: url('Pro7.jpg');
        background-repeat: no-repeat;
        background-attachment:fixed;
        background-size:100% 100%;
        color:black;
        margin-bottom: 10%;
        padding:5px;
        position: relative;
    
    }
    .abc{
        
        border: 1px solid bisque;
        border-spacing: 10px;
        box-shadow: 10px 20px 10px green;
        background-color:#0000007c;
        color: aliceblue;
        width: 1000px;
        margin-left: 180px;
        margin-top: 120px;
        } 

    
    
    
    input[type='submit']{
        background-color:blue;
        background-color: #04AA6D;
        border:none;
        color:white;
        text-decoration:none;
        margin:4px 4px;
        cursor:pointer;
        padding:16px 32px;
        box-shadow:10px 20px 10px green;
    }
</style>
<body>
    <div class="abc">
 <i>   
<h1>Welcme to our Game!</h1>
<h1>Are you ready?</h1>
<h1>Now chosse your hero!</h1></i>
<h2>

<form action="" method="post">
<label for="players">Choose player:</label>
<input type ='radio' value='1' name='2'>Messi &emsp;
<input type ='radio' value='2' name='2'>Pedri &emsp;
<input type ='radio' value='3' name='2'>Ronaldo &emsp;
<input type ='radio' value='4' name='2'>Dybala &emsp;
<input type ='radio' value='5' name='2'>De Bruyne

<br><br><input type="submit" name="submit" >

</form>
<?php
$rb=$_POST['2'];
switch ($rb){
    case 1:
        header ('location:form.php');
        exit;
    break;
    case 2:
        header ('location:form1.php');
        exit;
    break;
    
    case 3:
        header ('location:form2.php');
        exit;
    break;
    
    case 4:
        header ('location:form3.php');
        exit;
    break;
    
    case 5:
        header ('location:form4.php');
        exit;
    break;
}
?>
</div>
</body>
</html>