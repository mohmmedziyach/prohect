<!DOCTYPE html>
<html><head><title>Mo Education</title>
<link rel="stylesheet" href="admi.css">
</head>
<style>
</style>
<body>
    
<div class="A">
<form method ="post">
    <H1> WELCOME ADMIN</H1>
    <br><br><br>
    <div class="n">
    <input class="b1" type="submit" value="COURSES" name="#">
    <input class="b1" type="submit" value="LECTUERS" name="ab">
    <input class="b1" type="submit" value="USERS" name="u">
    <label for="role">Job:</label><br>
    &emsp;&emsp;<input type="radio" value="student" name="g">Student &emsp;
    <input type="radio" value="Maneger" name="g">Maneger &emsp;
    <input type="radio" value="Teacher" name="g">Teacher &emsp;<br>
    <input class="b1" type="submit" value="BACK" name="b">
    </div>
    </form>

</div>
</section>


</body>
</html>
<?php
error_reporting(0);
if ($_POST["c"]== True)
{
    echo '<script
type="text/javascript">window.location.href="courses.php";</script>';
}
if ($_POST["r"]== True)
{
    echo '<script
type="text/javascript">window.location.href="log.php";</script>';
}
if ($_POST["ab"]== True)
{
    echo '<script
type="text/javascript">window.location.href="lecurse.php";</script>';
}
if ($_POST["u"]== True)
{
    echo '<script
type="text/javascript">window.location.href="users.php";</script>';
}
;if ($_POST["b"]== True)
{
    echo '<script
type="text/javascript">window.location.href="log.php";</script>';
}
?>