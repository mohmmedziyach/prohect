<!DOCTYPE html>
<html><head><title>Mo Education</title>
<link rel="stylesheet" href="users.css">
</head>
<body>
    <br><br>
    <table>
<h1>Check users</h1> 
    <thead>
      <tr> 
       <th scope="col"> Name</th>
       <th scope="col">Email</th>
       <th scope="col">Username</th>
       <th scope="col">Job</th>
      
      </tr>
    </thead>
</div>
     </table>
<?php
$conn=new mysqli("localhost","root","","education");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="SELECT * FROM rego";
$result2 =mysqli_query($conn, $sql);
if($result2->num_rows > 0)
{
while($row = $result2->fetch_assoc()){
?>

<table>

     <tr>
       <td><?php echo $row['name']; ?></td>
       <td><?php echo $row['email']; ?></td>
       <td><?php echo $row['usename']; ?></td>
       <td><?php echo $row['job']; ?></td>
     </tr>

     </table>
    
<?php
}
}
?>
 <br><br>
</body>
</html>