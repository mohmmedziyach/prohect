<!DOCTYPE html>
<html><head><title>OneLine Book Store</title>
<link rel="stylesheet" href="book.css">
</head>
<style>
    .a{
        text-align:center;
    }
</style>
<body>
    <div class="A">
        <i>
    <h1>Registertion</h1>
    <h2>
        
    <form method="post">
        <label for="Name">Name:</label><br>
        <input type="text" name="na"  value='Inter Your First Name' onfocus="this.value=''"><br>
        <label for="Age">Age:</label><br>
        <input type="text" name="age"  value='Inter Your age' onfocus="this.value=''"><br>
        <label for="Email Address">Email Address:</label><br> 
        <input type="text" name="em"  value='Inter Your Email Address' onfocus="this.value=''"><br> 
        <label for="password">Password:</label><br> 
        <input type="text" name="ps"  value='Inter Your Password' onfocus="this.value=''"><br>
        <label for="Choose">Favorite Type of books:</label><br>
        <input type="text" name="ch" value='Inter Your Favorite Type of Books'onfocus="this.value=''">
        &emsp;&emsp;&emsp;&emsp;<div class="a"><input class="b1" type="submit" value="sign in" name="submit"></div>
        <br>
    </form>
</h2>
</i>

<?php
if($_POST["submit"]== True)
{
$user=$_POST["na"];
$age=$_POST["age"];
$em=$_POST["em"];
$up=$_POST["ps"];
$ch=$_POST["ch"];
if ($_POST["g"]=="m"){
    $g="male";
}
elseif($_POST["g"]=="f"){
    $g="female";
}
elseif($_POST["g"]=="u"){
    $g="Unspecified";
}
if($user=="Inter Your First Name"|| $age=="Inter Your age" || $em=="Inter Your Email Address"
||$up=="Inter Your Password"  ||$ch=="Inter Your Favorite Type of Books"){
    echo "<script>alert('Please enter Full data')</script>";
}
else {
$conn=new mysqli("localhost","root","12345","bookstore");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="INSERT INTO accounts(name,age,email,password,favorite,gender) VALUES('$user','$age','$em','$up','$ch','$g')";?>

<?php
if ($conn->query($sql)==TRUE)
{?><h1><?php
	echo "new user created succesfully ";?></h1>
    <form action ="ch.php" method='post'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="submit" value= "check datels of us " name ="submit" class="b1"></form>
<?php

}
else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}
if($user=="Inter Your First Name"|| $age=="Inter Your age" || $em=="Inter Your Email Address"
||$up=="Inter Your Password"  ||$ch=="Inter Your Favorite Type of Books"){
    echo "<script>alert('Please enter Full data')</script>";
}
}
}
?>
</div>
</body>
</html>
