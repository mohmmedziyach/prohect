<link rel="stylesheet" href="main.css">
<section class="footer">
            <article class="right">
                <h2 class="now">Now Send a Massage!</h2><br>
                <form>
                    <input type="text" name="name" value="Your name">
                    <input type="text" name="email" value="Your email"><br>
                    <input type="text" name="message" value="Your message"><br>
                    <input type="submit" name="sub" value="Send Message">
                </form>
          </article>
            <article class="contect">
                <div class="p">
                <h2 class="cont">CONTACT US:</h2>
                <h2>
                <p>Location:Alriyad-The Sixty street</p><br>
                <p>Specialization:Programming Language , Web Development , Mobile Apps</p><br>
                <p>Mobile Number: +249 992100934</p><br>                    
                <p>For more information: send to <a href="mailto=mohmmedziyach@gmail.com">mohmmedziyach@gmail.com</a></p></h2>
            </article>
          </section>
          
    </div>
</main>
</body>
</html>