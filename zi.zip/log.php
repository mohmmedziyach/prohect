<!DOCTYPE html>
<html><head><title>Mo Education</title>
<link rel="stylesheet" href="log.css">
</head>
<style>
.a,h1{
    text-align:center;
}
h5{
    padding-left:60px;
}
</style>
<body>
<h2>
    <div class="A">
        <i>
    <h1>Log In</h1>
    <h5>If you an admin inter admin and enter password</h5>
    <form action="" method ="post">
    <label for="email">Email:</label>
    <input type="text" name="em" onfocus="this.value=''" value="Enter your Email address" >
    <label for="Password">Password:</label>
    <input type="text" name="pass" onfocus="this.value=''" value="Enter your password"><br>
    &emsp;&emsp;&emsp;<div class="a"><input type="submit" value="LOG IN" name="log" class="b1"></div> 
</h2>
</form>
</i>
   </div>
</body>
</html>
<?php
error_reporting(0);
?>
<?php 
if ($_POST["log"]== True){
    $conn=new mysqli("localhost","root","","education");
    $user=$_POST['em'];
    $pass=$_POST['pass'];
    if($conn->connect_error)
        
    {
        die("Connection failed:".$conn->connect_error);
    }
    $sql="SELECT * FROM rego WHERE email='$user' AND password='$pass'";
    $result =mysqli_query($conn, $sql);
    if($user=='admin' AND $pass=='123456789')
    {
        echo '<script
        type="text/javascript">window.location.href="admin.php";</script>';
    }
    if($result->num_rows > 0)
    {
    $_SESSION['em'] = $row['email'] && $_SESSION['pass'] = $row['password'];
    echo '<script
    type="text/javascript">window.location.href="ch.php";</script>';
    }
    else
    {
    echo "<script>alert('wrong email or password')</script>";	
    }
    }
    ?>