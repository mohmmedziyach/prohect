<?php
require ("header.php");
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" href="paid.css">       
</head>
<body>
        <section class="n">
            <button class="aaa"> 
             <article class="courses">
               <h3>Web Devolopment</h3>
               <h3>paid Course</h3>
               <h3>99$</h3>
               <a href=""><h3>Get It</h3></a>
               </article></button><button class="aaa"> 
                   <article class="courses">
                     <h3>Mopile Apps</h3>
                     <h3>Paid Course</h3>
                     <h3>99$</h3>
                     <a href=""><h3>Get It</h3></a>
                     </article></button><button class="aaa"> 
             <article class="courses">
               <h3>Data Analysis</h3>
               <h3>paid Course</h3>
               <h3>99$</h3>
               <a href=""><h3>Get It</h3></a>
               </article></button>
               </section>
            
                       
</body>
</html>
<?php
require ("footer.php");
?>