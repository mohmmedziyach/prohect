<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" type="text/css" href="register.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>       
</head>
<body>
    <span class="cir1"></span>
    <span class="cir2"></span>
<form action="" method="post" >

        
            <h1 class="formhead">Sign Up</h1>
            <p class="formp">Please fill in this form to create an account.</p>

            <label for="name"><b>Name</b></label><br>
            <input type="text" name="name"  value='Enter Name' onfocus="this.value=''"> <br>
            

            <label for="email"><b>Email</b></label><br>
        <input type="text" name="email"  value='Enter Email' onfocus="this.value=''"> <br>
            
            <label for="user"><b>Username</b></label><br>
            <input type="text" name="user"  value='Enter User Name' onfocus="this.value=''"> <br>


            <label for="psw"><b>Password</b></label> <br>
            <input type="text" name="psw"  value='Enter Password' onfocus="this.value=''"> <br>
            

            <label for="pswrepeat"><b>Repeat Password</b></label><br>
            <input type="text" name="pswrepeat"  value='Repeat Password' onfocus="this.value=''"> <br>
            
            <input type="submit" name="submit" value="Sign Up" class="formbtn">
             <p class="login">Already have account? <a href="log.php">Login</a></p>
    </form>    
</body>
</html>
<?php
if($_POST["submit"]== True)
{
error_reporting(0);
$name=$_POST["name"];
$em=$_POST["email"];
$user=$_POST["user"];
$pass=$_POST["psw"];
$rpass=$_POST["pswrepeat"];
if($name=="Enter Name"|| $em=="Enter Email" || $user=="Enter User Name"
||$pass=="Enter Password"  ||$rpass=="Repeat Password"){
    echo "<script>alert('Please enter Full data')</script>";
}
else {
$conn=new mysqli("localhost","root","","education");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="INSERT INTO rego(name,email,username,password,rpassword) VALUES('$user','$em','$user','$pass','$rpass')";?>

<?php
if ($conn->query($sql)==TRUE)
{?><h1>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php
	echo "new user created succesfully ";?></h1>
    <form action ="main.php" method='post'>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
        <input type="submit" value= "Go To Main Page " name ="submit" class="formbtn"></form>
<?php
}
else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}
if($name=="Enter Name"|| $em=="Enter Email" || $user=="Enter User Name"
||$pass=="Enter Password"  ||$rpass=="Repeat Password"){
    echo "<script>alert('Please enter Full data')</script>";
}
}
}
?>