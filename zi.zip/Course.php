<?php
require ("header.php");
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" href="Course.css">       
</head>
<body>
     <section class="n">
     <button class="aaa"> 
      <article class="courses">
        <p class="course">
            Dive into HTML
        </p>
        <h3>HTMl Basics</h3>
        <h3>Free Course</h3>
        <a href=""><h3>Get It</h3></a>
        </article></button><button class="aaa">
            <article class="courses">
              <p class="course">
                  Dive into CSS
              </p>
              <h3>CSS Basics</h3>
              <h3>Free Course</h3>
              <a href=""><h3>Get It</h3></a>
              </article></button><button class="aaa"> 
      <article class="courses">
        <p class="course">
            Dive into PHP
        </p>
        <h3>PHP Basics</h3>
        <h3>Free Course</h3>
        <a href=""><h3>Get It</h3></a>
        </article></button>
        </section><section class="n">
            <button class="aaa"> 
             <article class="courses">
               <p class="course">
                   Dive into JAVASCRIPT
               </p>
               <h3>JAVASCRIPT Basics</h3>
               <h3>Free Course</h3>
               <a href=""><h3>Get It</h3></a>
               </article></button><button class="aaa"> 
                   <article class="courses">
                     <p class="course">
                         Dive into PERL
                     </p>
                     <h3>PERL Basics</h3>
                     <h3>Free Course</h3>
                     <a href=""><h3>Get It</h3></a>
                     </article></button><button class="aaa"> 
             <article class="courses">
               <p class="course">
                   Dive into PYTHON
               </p>
               <h3>PYTHON Basics</h3>
               <h3>Free Course</h3>
               <a href=""><h3>Get It</h3></a>
               </article></button>
               </section>
            
                       
</body>
</html>
<?php
require ("footer.php");
?>