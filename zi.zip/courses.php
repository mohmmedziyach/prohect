<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html><head><title>Mo Education</title>
</head>
<link rel="stylesheet" href="courses.css">
<body>

<h2>
    <div class="A">
        <i>
    <h1>COURSES</h1> 
    <form method ="post">
    <label for="id">ID:</label>
    <input type="text" name="id" onfocus="this.value=''" value="Enter Course id" >
    <label for="name">name:</label>
    <input type="text" name="name" onfocus="this.value=''" value="Enter Course Name">
    <label for="name">Techear:</label>
    <input type="text" name="tech" onfocus="this.value=''" value="Enter Techear Name">
    <br><br>
    &emsp;&emsp; <input type="submit" value="ADD" name="add" class="b1">
    &emsp;&emsp; <input type="submit" value="Delete" name="del" class="b1">
    &emsp;&emsp; <input type="submit" value="Update" name="up" class="b1">
    <input type="text" class="l" name="cid" onfocus="this.value=''" value="Course id want to update">
    
</h2>
</form>
</i>
   </div>
</body>
</html>
<?php 
  $id=$_POST['id'];
  $na=$_POST['name'];
  $th=$_POST['tech'];
  if($na=="Enter Course Name"|| $id=="Enter Course id"|| $th=="Enter Teacher Name")
 {
    echo "<script>alert('Please enter Full course data')</script>";
 }
 else
 {
$conn=new mysqli("localhost","root","","education");
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="SELECT * FROM courses WHERE name='$na'";
$result =mysqli_query($conn, $sql);
if($result->num_rows > 0)
{
    if($_POST['add']== true)
  {
$sql="INSERT INTO courses(id,name,tech) VALUES('$id','$na','$th')";
 if ($conn->query($sql)===TRUE)
{?><h1><?php
	echo "new course created succesfully ";?></h1>
<?php
}
else 
{
	echo "Erorr:".$sql."<br>".$conn->erorr;
}

}
if($_POST['del']== true){
  $sql="DELETE FROM courses WHERE name='$na' && id='$id' && tech='$th'";
  if($conn->query($sql)==true)	
  {
    echo " record deleted";
  }
  else
  {
      echo "error in deleting record".$conn->error;
  }
}
if($_POST['up']== true){
  $sql="UPDATE courses SET name='$na',id='$id',techears='$th' WHERE id='$cid'";
  if ($conn->query($sql)===TRUE)
  {?><h1><?php
    echo "user update succesfully ";?></h1>
  <?php
  } 
  else 
  {
    echo "Erorr:".$sql."<br>".$conn->erorr;
  }
}
}

}
?>