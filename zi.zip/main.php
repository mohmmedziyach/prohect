<?php 
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" href="main.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>       
</head>
<body>
    <main>
    <article>
        <header>
    <div class="grid">
        <div>
            <nav class="nav">
            <input type="checkbox" id="check">
            <label for="check">
            <i class="fas fa-bars"></i></label>
            <label class="logo">MMMd</label>
            <ul>
                <li><a href="main.php" class="h">Home</a></li>
                <li><a href="About.php" class="h">about</a></li>
                <li><a href="Course.php" class="h">courses</a></li>
                <li><a href="feedback.php" class="h">feedback</a></li>
                <li><div class="search-box">
                <button class="btn-search"><i class="fas fa-search"></i></button>
                <input type="text" class="input-search" placeholder="Type to Search...">
                </div></li>
            </ul>
        </nav>
    </header>            
        </div>
        <div>
        </article>
    <section class="jambbotron">
        <div class="new">
           <h1>Welcome to new world</h1><br>
           <a href="register.php">login </a><span>or</span><a href="w.php"> learn more</a>
        </div>
        </section>
        </div>
    <div>
    <section class="Some">
        <h2 class="some">Some of our populer courses</h2><br>

    </section>
</div>
<div class="pop">    
<button class="aaa"> <article class="courses">
<p class="course">
    Dive into HTML
</p>
<h3>HTMl Basics</h3>
</article></button>
<button class="aaaa"> <article class="courses">
 <p class="course">
        Dive into CSS
    </p>
    <h3>CSS Basics</h3>
    </article></button>
    <button class="aa"><article class="courses">

        <p class="course">
            Dive into JS
        </p>
        <h3>JS Basics</h3>
        </article></button>
    </section>
    </div>
    <section class="money">
        <article>
            <h3>We also have a good privde lessons with very good price <a href="paid.php" class="t">Try them</a></h3>
        </article>
    </section>
    <div>
    <section class="what">
        <article class="message">
            <h2 class="l">Leave a Message For Us!</h2><br>
            <h2>
            <form>
            <input type="text" name="name" value="Your name">
                <input type="text" name="email" value="Your email"><br>
                <input type="text" name="message" value="Your message"><br>
                <input type="submit" name="sub" value="Send Message">
            </form>
            </h2>
        </article>
        <article class="studants">
            <h2 class="w">What Our Studants Say</h2><br>
            <div class="A">
                <h3>Mohmmed:</h3>
                <p>Good courses that can improve you very well.</p>
            </div>&emsp;
            <div class="B">
                <h3>Malik:</h3>
                <p>You can find any thing has relationship with Softwore World.</p>
            </div>&emsp;
            <div class="C">
                <h3>Rawnq:</h3>
                <p>Its a very good program that can make you good programmer.</p>
            </div>&emsp;
            <div class="D">
                <h3>Safaa:</h3>
                <p>Its a Big chance Do not miss it.</p>
            </div>
        </article>
        </section>
        </div>
        <section class="footer">
            <article class="right">
                <h2 class="now">Now Send a Massage!</h2><br>
                <form>
                    <input type="text" name="name" value="Your name">
                    <input type="text" name="email" value="Your email"><br>
                    <input type="text" name="message" value="Your message"><br>
                    <input type="submit" name="sub" value="Send Message"> 
                    <?php
                    if ($_POST["submit"]==TRUE)
                    {?><h3>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php
	                echo "Thank You  for you message";}?></h3>
 
                </form>
          </article>
            <article class="contect">
                <div class="p">
                <h2 class="cont">CONTACT US:</h2>
                <h2>
                <p>Location:Alriyad-The Sixty street</p><br>
                <p>Specialization:Programming Language , Web Development , Mobile Apps</p><br>
                <p>Mobile Number: +249 992100934</p><br>                    
                <p>For more information: send to <a href="mailto=mohmmedziyach@gmail.com">mohmmedziyach@gmail.com</a></p></h2>
            </article>
          </section>
          
    </div>
</main>
</body>
</html>