<?php
require ('header.php');
?>
<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mo Education</title>
    <link rel="stylesheet" type="text/css" href="feedback.css">
</head>
<body>
    <span class="cir1"></span>
    <span class="cir2"></span>

<form action="" method="post" >

        
            <h1 class="formhead">Give Us Your Feedback !</h1>

            <label for="name"><b>Name</b></label><br>
            <input type="text" name="na"  value='Enter Name' onfocus="this.value=''"> <br>
            

            <label for="email"><b>Email</b></label><br>
        <input type="text" name="em"  value='Enter Email' onfocus="this.value=''"> <br>
            
            <label for="feed"><b>Feedback</b></label><br>
            <input type="text" name="feed"  value='Enter Your Feedback' onfocus="this.value=''"> <br>


            <input type="submit" name="submit" value="Send" class="formbtn">
            <?php
  if ($_POST["submit"]==TRUE)
    {?><h3>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<?php
	 echo "Thank You  for you message";}?></h3>
 
    </form>    
</body>
</html>
<?php
if($_POST["submit"]== True)
{
$name=$_POST["na"];
$em=$_POST["em"];
$feed=$_POST["feed"];
$conn=new mysqli("localhost","root","","education");
if($name=="Enter Name"|| $em=="Enter Email" || $feed=="Enter Your Feedback"){
    echo "<script>alert('Please enter Full data')</script>";
}
else {
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
$sql="INSERT INTO feedback(na,em,feed) VALUES('$name','$em','$feed')";                      
}

}

?>
