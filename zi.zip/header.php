<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mo Education</title>
    <link rel="stylesheet" href="main.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>       
</head>
<body>
    <main>
    <article>
        <header>
    <div class="grid">
        <div>
            <nav class="nav">
            <input type="checkbox" id="check">
            <label for="check">
            <i class="fas fa-bars"></i></label>
            <label class="logo">MMMd</label>
            <ul>
                <li><a href="main.php" class="h">Home</a></li>
                <li><a href="w.php" class="h">about</a></li>
                <li><a href="Course.php" class="h">courses</a></li>
                <li><a href="feedback.php" class="h">feedback</a></li>
                <li><div class="search-box">
                <button class="btn-search"><i class="fas fa-search"></i></button>
                <input type="text" class="input-search" placeholder="Type to Search...">
                </div></li>
            </ul>
        </nav>
    </header>            
        </div>
        <div>
        </article>
